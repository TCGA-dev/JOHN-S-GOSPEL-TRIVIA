# John's Gospel Trivia — Flutter Android Project

An offline Bible trivia app covering the 21 chapters of the Gospel of John.

## Features
- Quick Quiz (10 randomized questions)
- Chapter Challenge
- Full Gospel question bank
- Multiple-choice answers with immediate feedback
- Scripture references and explanations
- Score and quiz completion screen
- Offline question database

## Build locally
Install Flutter stable, then run:
```bash
flutter pub get
flutter run
```
To build an Android APK:
```bash
flutter build apk --release
```
APK output: `build/app/outputs/flutter-apk/app-release.apk`

## GitHub Actions build
Upload this project to a GitHub repository. The included workflow creates Flutter's Android platform files and builds a release APK on push or manual run. Download the APK from the workflow's Artifacts section.

Question content is an initial curated bank (three questions per chapter). Expand the JSON bank before a full competitive release; review each question and reference against the Bible translation chosen for your ministry.
